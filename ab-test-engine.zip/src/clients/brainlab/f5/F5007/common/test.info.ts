export enum TestInfo {
  ID = "F5007",
  SITE = "f5",
  TITLE = "BLTEST032 - Email Sign Up Form - Popup vs On-Page",
  CLIENT = "brainlab",
  TARGET = "https://www.f5.com/go/solution/hybrid-multi-cloud-security",
  VARIATION = "2",
}
