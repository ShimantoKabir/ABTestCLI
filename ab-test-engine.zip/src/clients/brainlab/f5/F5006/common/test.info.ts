export enum TestInfo {
  ID = "F5006",
  SITE = "f5",
  CLIENT = "brainlab",
  TARGET = "https://www.f5.com/company/events/webinars/api-discovery-inventory-and-security-webinar",
  VARIATION = "1",
}
