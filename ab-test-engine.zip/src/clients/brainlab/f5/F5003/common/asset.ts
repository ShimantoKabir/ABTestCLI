export const selectors = {
  heroBannerBtnSelector: "div.c01__button>a",
  videoWrapperSelector: "div.f5modal",
  videoCloseBtnSelector: "button.f5modal__close-button",
};
