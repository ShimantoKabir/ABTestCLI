export class CartModel {
  imgSrc: string = "";
  linkText: string = "";
  href: string = "";
  title: string = "";
}
