export const selectors = {
  buyingButton: "div#atom309393897>p>a",
};

export const buyingButtonHTML: string =
  "<div>Check out the WAAP Buying Guide<br>(quick read)</div>";

export const buyingButtonHref: string =
  "https://www.f5.com/resources/articles/waap-buying-guide";
