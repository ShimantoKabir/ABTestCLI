export enum TestInfo {
  ID = "CI002",
  SITE = "classicindustries",
  TITLE = "6.1 - remove nav from checkout process",
  CLIENT = "brainlab",
  TARGET = "https://www.classicindustries.com/shoppingcart",
  VARIATION = "1",
}
