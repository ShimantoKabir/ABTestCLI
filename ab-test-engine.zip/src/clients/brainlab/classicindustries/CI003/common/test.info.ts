export enum TestInfo {
  ID = "CI003",
  SITE = "classicindustries",
  TITLE = "7.1_VLP_Catalog Download_PopUpForm",
  CLIENT = "brainlab",
  TARGET = "https://shop.classicindustries.com/lp/1958-1996_chevrolet_impala_and_full_size_chevrolet_parts",
  VARIATION = "1",
}
