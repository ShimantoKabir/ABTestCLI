export enum TestInfo {
  ID = "CI001",
  SITE = "classicindustries",
  TITLE = "2.1_promo banner_make clickable_reduce size",
  CLIENT = "brainlab",
  TARGET = "https://www.classicindustries.com/",
  VARIATION = "1",
}
