export enum TestInfo {
  ID = "CC013",
  SITE = "consumercellular",
  TITLE = "6.11-Show pricing on a per line basis",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "1",
}
