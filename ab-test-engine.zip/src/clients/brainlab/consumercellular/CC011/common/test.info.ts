export enum TestInfo {
  ID = "CC011",
  SITE = "consumercellular",
  TITLE = "6.9M - Pricing is scroll off screen",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "2",
}
