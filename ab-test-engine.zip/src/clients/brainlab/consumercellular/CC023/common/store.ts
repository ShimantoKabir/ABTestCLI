export class Store {
  public isComponentMoved: boolean = false;
  public isModificationApplied: boolean = false;
}
