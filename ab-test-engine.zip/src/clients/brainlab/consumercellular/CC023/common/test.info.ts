export enum TestInfo {
  ID = "CC023",
  SITE = "consumercellular",
  TITLE = "8.15M - Due Today Placement",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping",
  VARIATION = "1",
}
