export enum TestInfo {
  ID = "CC016",
  SITE = "consumercellular",
  TITLE = "9.3 Trust Signals on Checkout",
  CLIENT = "brainlab",
  TARGET = "https://consumercellular.com/shopping/checkout",
  VARIATION = "1",
}
