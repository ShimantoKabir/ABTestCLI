export enum TestInfo {
  ID = "CC020",
  SITE = "consumercellular",
  TITLE = "9.16 Hyphens Vs. Spaces",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/checkout",
  VARIATION = "2",
}
