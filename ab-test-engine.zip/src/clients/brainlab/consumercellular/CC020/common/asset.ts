export const selectors = {
  cardInput: "input#ccNumber",
};
