export enum TestInfo {
  ID = "CC015",
  SITE = "consumercellular",
  TITLE = "6.4 - Order of Plan Pricing",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "3",
}
