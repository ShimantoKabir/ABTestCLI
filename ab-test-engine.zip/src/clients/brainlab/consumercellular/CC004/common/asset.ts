export const selectors = {
  modelFooter: "div.cci-modal-body>div.row",
  existMobileCartButton: "div#mobile-bill-breakdown button.btn-shop",
  modal:
    "div#shopping-page-container > div > div.added-to-cart-modal > div.cci-modal-mask",
  modalCloseButton:
    "div#shopping-page-container > div > div.added-to-cart-modal > div > div > div > div > button.cci-shopping-modal-close",
};
