export enum TestInfo {
  ID = "CC017",
  SITE = "consumercellular",
  TITLE = "6.12 Trust Signals on plans",
  CLIENT = "brainlab",
  TARGET = "http://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "1",
}
