export enum TestInfo {
  ID = "CC029",
  SITE = "consumercellular",
  TITLE = "XT4.19D - Shopping Page Tile Rotation",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/device",
  VARIATION = "2",
}
