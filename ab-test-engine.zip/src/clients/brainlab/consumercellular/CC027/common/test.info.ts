export enum TestInfo {
  ID = "CC027",
  SITE = "consumercellular",
  TITLE = "11.1 - Trade in Messaging on BYOD",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/device",
  VARIATION = "1",
}
