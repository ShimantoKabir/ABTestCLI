export const selectors = {
  planSummary: "div.base-plan-summary-component",
};
