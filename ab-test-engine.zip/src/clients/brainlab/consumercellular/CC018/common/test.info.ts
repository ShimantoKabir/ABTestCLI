export enum TestInfo {
  ID = "CC018",
  SITE = "consumercellular",
  TITLE = "8.13 Money back guarantee (cart summary)",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping",
  VARIATION = "2",
}
