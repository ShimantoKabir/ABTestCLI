export enum TestInfo {
  ID = "CC028",
  SITE = "consumercellular",
  TITLE = "XT11.2 - subtext on byod",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/details/sim/details",
  VARIATION = "1",
}
