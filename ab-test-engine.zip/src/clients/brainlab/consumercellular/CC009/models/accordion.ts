export class Accordion {
  accordionGroupIndex!: number;
  accordionGroupsIndex!: number[];
}
