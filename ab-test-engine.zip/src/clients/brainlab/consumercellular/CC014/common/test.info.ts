export enum TestInfo {
  ID = "CC014",
  SITE = "consumercellular",
  TITLE = "4.9 Remove Full Price",
  CLIENT = "brainlab",
  TARGET = "http://www.consumercellular.com/shopping/choose/device",
  VARIATION = "2",
}
