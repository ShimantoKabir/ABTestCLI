export enum TestInfo {
  ID = "CC025",
  SITE = "consumercellular",
  TITLE = "1.3D - $25 Off Site Exit Modal",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "1",
}
