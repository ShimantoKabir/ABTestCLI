export enum TestInfo {
  ID = "CC022",
  SITE = "consumercellular",
  TITLE = "7.13 - Product selection colorway",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/details/moto_g_5g_2023/details",
  VARIATION = "1",
}
