export const selectors = {
    checkoutBtn1 : "div.btn-checkout>a",
    checkoutBtn2: "div.review-order-button>a",
    
    shopingPageContainer: "div#shopping-page-container"
}
