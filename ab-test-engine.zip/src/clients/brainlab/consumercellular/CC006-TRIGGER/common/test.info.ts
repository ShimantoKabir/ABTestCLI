export enum TestInfo {
  ID = "CC006-TRIGGER",
  SITE = "consumercellular",
  TITLE = "6.9M.2 - “Add a device” vs. “Bring your own device” modal on mobile - TRIGGER",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "all",
}
