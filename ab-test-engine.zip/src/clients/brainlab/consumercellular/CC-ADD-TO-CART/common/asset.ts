export const pageData = {
  planPage: {
    desktopCtaSelector: "div.hide-phone-down button.btn-shop",
    mobileCtaSelector: "div#mobile-bill-breakdown button.btn-shop",
    mBoxName: "plan-page-add-to-cart",
    targetClass: "bill-box",
    siblingClass: "base-dollar-display-component",
  },
};
