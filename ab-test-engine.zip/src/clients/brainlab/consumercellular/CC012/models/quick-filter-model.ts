export class QuickFilterModel {
  id: number = 2;
  label: string = "";
  parentPosition: number = 0;
  childPosition: number = 0;
  variation: number = 0;
}
