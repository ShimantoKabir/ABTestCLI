export enum TestInfo {
  ID = "CC026",
  SITE = "consumercellular",
  TITLE = "XT2.1 - Español link in Nav",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "1",
}
