export const selectors = {
  rightHeader: "li.right-header",
  homeRightHeader: "nav>div>div:nth-child(2)",
};

export const espanolLink: string =
  "https://savings.consumercellular.com/espanol?mboxEdit=1&mboxDisable=1&adobe_authoring_enabled=1";
