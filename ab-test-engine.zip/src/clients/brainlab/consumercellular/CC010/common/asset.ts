export const selectors = {
  shoppingPageContainer: "div#shopping-page-container",
  promoSection: "div.grid-item-container.promo",
};

export const pathnames = {
  device: "/shopping/choose/device",
};
