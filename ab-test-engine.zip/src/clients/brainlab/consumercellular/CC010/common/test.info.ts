export enum TestInfo {
  ID = "CC010",
  SITE = "consumercellular",
  TITLE = "Replace the promotion image on the choose device page",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/device",
  VARIATION = "1",
}
