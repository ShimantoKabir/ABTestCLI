export const selectors = {
  cartSummary: "div#cart-summary-details",
};

export const reviewLibrary: string =
  "https://www.shopperapproved.com/widgets/14219/merchant/rotating-widget/default.js?v=1";
