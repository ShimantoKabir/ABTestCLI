export enum TestInfo {
  ID = "CC019",
  SITE = "consumercellular",
  TITLE = "8.14 Social Proof Reviews",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping",
  VARIATION = "1",
}
