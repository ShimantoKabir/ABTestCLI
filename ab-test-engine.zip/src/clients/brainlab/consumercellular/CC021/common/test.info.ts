export enum TestInfo {
  ID = "CC021",
  SITE = "consumercellular",
  TITLE = "8.13.2 Messaging on Cart Summary",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping",
  VARIATION = "3",
}
