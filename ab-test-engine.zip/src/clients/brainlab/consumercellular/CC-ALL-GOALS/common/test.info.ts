export enum TestInfo {
  ID = "CC-ALL-GOALS",
  SITE = "consumercellular",
  TITLE = "All goals for consumer cellular",
  CLIENT = "brainlab",
  TARGET = "https://www.consumercellular.com/shopping/choose/plan",
  VARIATION = "1",
}
