export enum TestInfo {
  ID = "CC001",
  SITE = "consumercellular",
  TITLE = "LP1.1 - SEM Brand Redirect",
  CLIENT = "brainlab",
  TARGET = "https://savings.consumercellular.com/sembrand",
  VARIATION = "1",
}
