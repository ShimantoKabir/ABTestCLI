export const selectors = {
  leftHeadlineSelector: "h1.dark-blue",
};

export const leftHeadlineText =
  "Get Access to<br> the Leading<br> OT Travel Jobs";
