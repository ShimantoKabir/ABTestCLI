export const selectors = {
  heroContainerSelector: "div.imagebackground-page-wrapper",
  header: "div.imagebackground-page-headers",
  content: "div.imagebackground-page-content",
};
