export const selectors = {
  hiddenSelectors: [
    "div.base-page-hero-content-image",
    "ul.base-page-hero-content-links-wrapper",
    "div.base-page-hero-content-buttons",
  ],
};
