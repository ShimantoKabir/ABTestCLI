export const selectors = {
  glideSlidesNthList: "section.carousel-section ul.glide__slides>li:nth-child",
};

export const customEventName: string = "glide-3rd-or-6th-link-click";
