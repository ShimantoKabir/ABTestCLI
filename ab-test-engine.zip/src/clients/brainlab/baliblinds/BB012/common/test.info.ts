export enum TestInfo {
  ID = "BB012",
  SITE = "baliblinds",
  TITLE = "4.6M - Sticky header w/ filter and product categories",
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com/swatches",
  VARIATION = "1",
}
