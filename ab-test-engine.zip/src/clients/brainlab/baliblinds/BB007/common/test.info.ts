export enum TestInfo {
  ID = "BB007",
  SITE = "baliblinds",
  TITLE = '4.9 - Lightbox CTA "View in visualizer" on swatch preview',
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com/swatches/",
  VARIATION = "1",
}
