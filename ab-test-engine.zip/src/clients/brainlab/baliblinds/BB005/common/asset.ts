export const selectors = {
  bannerSlider: "ul.glide__slides",
};
