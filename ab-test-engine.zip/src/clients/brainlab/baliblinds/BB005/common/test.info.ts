export enum TestInfo {
  ID = "BB005",
  SITE = "baliblinds",
  TITLE = "3.1 Homepage Product Advisor",
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com/",
  VARIATION = "1",
}
