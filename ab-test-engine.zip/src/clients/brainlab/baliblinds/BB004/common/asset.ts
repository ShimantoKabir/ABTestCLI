export const selectors = {
  listSelector: "ul.category-product-list",
  observerTargetNode: "section.swatch-container>div",
};
