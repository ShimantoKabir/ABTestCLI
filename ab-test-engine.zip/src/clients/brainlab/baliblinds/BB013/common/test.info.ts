export enum TestInfo {
  ID = "BB013",
  SITE = "baliblinds",
  TITLE = "5.4 Free Swatches CTA on product cards",
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com/products/blinds-shades",
  VARIATION = "1",
}
