export enum TestInfo {
  ID = "BB008",
  SITE = "baliblinds",
  TITLE = "3.1 Homepage Product Advisor Mid-Page Section",
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com/",
  VARIATION = "1",
}
