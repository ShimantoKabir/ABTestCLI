export const selectors = {
  dottedLink: "div.slide-caption-inner>a.dotted-link",
};
