export enum TestInfo {
  ID = "BB010",
  SITE = "baliblinds",
  TITLE = "3.4 Button CTAs vs Underline/Arrow",
  CLIENT = "brainlab",
  TARGET = "https://www.baliblinds.com",
  VARIATION = "1",
}
