export class OptionModel {
  href: string = "";
  text: string = "";
}
