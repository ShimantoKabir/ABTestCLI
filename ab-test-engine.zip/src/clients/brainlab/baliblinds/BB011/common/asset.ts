export const dummyContent: string = "Hello world!";
