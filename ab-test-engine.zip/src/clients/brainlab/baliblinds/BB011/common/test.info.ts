export enum TestInfo {
  ID = "BL011",
  SITE = "baliblinds",
  CLIENT = "brainlab",
  VARIATION = "1",
}
